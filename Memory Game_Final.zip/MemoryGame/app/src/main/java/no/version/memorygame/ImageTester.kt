package no.version.memorygame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ImageTester : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_tester)
    }
}