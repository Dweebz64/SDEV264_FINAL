package no.version.memorygame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_game.*
import kotlinx.android.synthetic.main.activity_preferences.*
import no.version.memorygame.R.drawable.*


class Game : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        menuBtn3.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        prefBtn.setOnClickListener {
            var intent = Intent(this, Preferences::class.java)
            startActivity(intent)
        }

        helpBtn2.setOnClickListener {
            var intent = Intent(this, Help::class.java)
            startActivity(intent)
        }

        val animalSet: MutableList<Int> =
            mutableListOf(cat, dog, bird, hamster, rabbit, fish, cat, dog, bird, hamster, rabbit, fish)
        val shapeSet: MutableList<Int> =
            mutableListOf(square, circle, diamond, oval, heart, triangle, square, circle, diamond, oval, heart, triangle)
        val fruitSet: MutableList<Int> =
            mutableListOf(apple, lemon, grape, watermelon, kiwi, cherry, apple, lemon, grape, watermelon, kiwi, cherry)
        val melSet: MutableList<Int> =
            mutableListOf(truck, robot, piano, bike, duck, paint, truck, robot, piano, bike, duck, paint)

        var images: MutableList<Int> = shapeSet

        when {
            animalBtn.isChecked -> images = animalSet
            shapeBtn.isChecked -> images = shapeSet
            fruitBtn.isChecked -> images = fruitSet
            melBtn.isChecked -> images = melSet
        }

//        val images: MutableList<Int> =
//            mutableListOf(cat, dog, bird, hamster, rabbit, fish, cat, dog, bird, hamster, rabbit, fish)


        val cards = arrayOf(card1,card3,card3,card4,card5,card6,card7,card8,card9,card10,card11,card12)

        val cardBack = ic_baseline_stars_24
        var clicked = 0
        var turnOver = false
        var lastClicked = -1



        images.shuffle()
        for(i in 0..11){
            cards[i].setImageResource(cardBack)
            cards[i].setTag(i,"cardBack")
//            cards[i].text = "cardBack"
//            cards[i].textSize = 0.0F
            cards[i].setOnClickListener {
                if (cards[i].getTag() == "cardBack" && !turnOver) {
                    cards[i].setImageResource(images[i])
                    cards[i].setTag(images[i])
                    if (clicked == 0) {
                        lastClicked = i
                    }
                    clicked++
                } else if (cards[i].getTag() != "cardBack") {
                    cards[i].setImageResource(cardBack)
                    cards[i].setTag(i,"cardBack")
                    clicked--
                }

                if (clicked == 2) {
                    turnOver = true
                    if (cards[i].getTag() == cards[lastClicked].getTag()) {
                        cards[i].isClickable = false
                        cards[lastClicked].isClickable = false
                        turnOver = false
                        clicked = 0
                    }
                } else if (clicked == 0) {
                    turnOver = false
                }
            }
        }
        }

    }
