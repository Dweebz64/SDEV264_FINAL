package no.version.memorygame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonNewGame.setOnClickListener {
            var intent = Intent(this, Game::class.java)
            startActivity(intent)
    }
        buttonGameMode.setOnClickListener{
            var intent = Intent(this, Preferences::class.java)
            startActivity(intent)
        }
        buttonHowToPlay.setOnClickListener{
            var intent = Intent(this, Help::class.java)
            startActivity(intent)
        }

    }


}